package com.meulauncher.tv;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Launcher cuja tela é o arquivo assets/index.html, mostrado numa WebView.
 * A página só conversa com o Android por uma ponte pequena (objeto "Android"):
 * lista de apps, abrir app, abrir configurações, baixar lista M3U e ler o fundo.
 */
public class HomeActivity extends Activity {
    private static final String PAGE = "file:///android_asset/index.html";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebView web;
    private String lastSig = "";
    private volatile boolean loadingApps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildWebView();
    }

    @SuppressWarnings({"deprecation", "SetJavaScriptEnabled"})
    private void buildWebView() {
        web = new WebView(this);
        web.setBackgroundColor(0xFF14352A);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false); // não afeta file:///android_asset
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        // A página é só a nossa (local). Isto deixa o player baixar canais de qualquer servidor.
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setSupportZoom(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true; // nunca sai da nossa página
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        lastSig = "";
                        if (web != null) {
                            web.destroy();
                        }
                        buildWebView();
                    }
                });
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public Bitmap getDefaultVideoPoster() {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.requestFocus();
        web.loadUrl(PAGE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps(false);
    }

    @Override
    protected void onPause() {
        js("window.stopPlayer&&window.stopPlayer()");
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        js("window.goHome&&window.goHome()");
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            js("window.onMenu&&window.onMenu()");
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        // Um launcher nunca fecha: a página decide o que o Voltar faz.
        js("window.handleBack&&window.handleBack()");
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    private void js(final String code) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript(code, null);
                }
            }
        });
    }

    private void toast(final String msg) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(HomeActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ------------------------------------------------------------------ apps

    private static final class Found {
        String pkg;
        String label;
        Drawable icon;
    }

    private void loadApps(final boolean force) {
        if (loadingApps) {
            return;
        }
        loadingApps = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    PackageManager pm = getPackageManager();
                    List<Found> list = new ArrayList<>();
                    Set<String> seen = new HashSet<>();
                    String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
                    for (String cat : cats) {
                        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
                        for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                            if (ri.activityInfo == null) {
                                continue;
                            }
                            String p = ri.activityInfo.packageName;
                            if (p.equals(getPackageName()) || !seen.add(p)) {
                                continue;
                            }
                            Found f = new Found();
                            f.pkg = p;
                            CharSequence l = ri.loadLabel(pm);
                            f.label = l == null ? p : l.toString();
                            f.icon = ri.loadIcon(pm);
                            list.add(f);
                        }
                    }
                    Collections.sort(list, new Comparator<Found>() {
                        @Override
                        public int compare(Found a, Found b) {
                            return a.label.toLowerCase(Locale.ROOT).compareTo(b.label.toLowerCase(Locale.ROOT));
                        }
                    });
                    StringBuilder sig = new StringBuilder();
                    for (Found f : list) {
                        sig.append(f.pkg).append(';');
                    }
                    String signature = sig.toString();
                    if (!force && signature.equals(lastSig)) {
                        return;
                    }
                    JSONArray arr = new JSONArray();
                    for (Found f : list) {
                        JSONObject o = new JSONObject();
                        o.put("p", f.pkg);
                        o.put("l", f.label);
                        o.put("i", iconBase64(f.icon));
                        arr.put(o);
                    }
                    lastSig = signature;
                    String b64 = Base64.encodeToString(arr.toString().getBytes("UTF-8"), Base64.NO_WRAP);
                    js("window.onApps('" + b64 + "')");
                } catch (Exception e) {
                    toast("Não foi possível listar os aplicativos");
                } finally {
                    loadingApps = false;
                }
            }
        }, "apps-loader").start();
    }

    private static String iconBase64(Drawable d) {
        int size = 96;
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, size, size);
        d.draw(c);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        b.recycle();
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    // ------------------------------------------------------------------ ponte

    private final class Bridge {
        @JavascriptInterface
        public void requestApps() {
            loadApps(true);
        }

        @JavascriptInterface
        public void launch(final String pkg) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        PackageManager pm = getPackageManager();
                        ResolveInfo ri = pm.resolveActivity(new Intent(Intent.ACTION_MAIN)
                                .addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER).setPackage(pkg), 0);
                        if (ri == null) {
                            ri = pm.resolveActivity(new Intent(Intent.ACTION_MAIN)
                                    .addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg), 0);
                        }
                        if (ri == null || ri.activityInfo == null) {
                            toast("Não foi possível abrir este aplicativo");
                            return;
                        }
                        Intent i = new Intent(Intent.ACTION_MAIN);
                        i.setComponent(new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                        startActivity(i);
                    } catch (Exception e) {
                        toast("Não foi possível abrir este aplicativo");
                    }
                }
            });
        }

        @JavascriptInterface
        public void openSettings(final String kind) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        String action = "wifi".equals(kind) ? Settings.ACTION_WIFI_SETTINGS : Settings.ACTION_SETTINGS;
                        startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) {
                        toast("Esta TV não permite abrir essa tela");
                    }
                }
            });
        }

        @JavascriptInterface
        public void appInfo(final String pkg) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) {
                        toast("Esta TV não abre as informações do app");
                    }
                }
            });
        }

        /** Baixa um texto (lista M3U). O resultado volta em window.onFetch(id, ok, base64). */
        @JavascriptInterface
        public void fetchText(final String id, final String address) {
            if (id == null || !id.matches("[A-Za-z0-9_]{1,20}")) {
                return;
            }
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String result = null;
                    try {
                        String u = address;
                        for (int hop = 0; hop < 6; hop++) {
                            if (u == null || !(u.startsWith("http://") || u.startsWith("https://"))) {
                                throw new IllegalArgumentException("endereço inválido");
                            }
                            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                            c.setInstanceFollowRedirects(false);
                            c.setConnectTimeout(15000);
                            c.setReadTimeout(20000);
                            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11) MeuLauncher");
                            int code = c.getResponseCode();
                            if (code >= 300 && code < 400) {
                                u = c.getHeaderField("Location");
                                c.disconnect();
                                continue;
                            }
                            if (code != 200) {
                                throw new IllegalStateException("http " + code);
                            }
                            InputStream in = c.getInputStream();
                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                            byte[] buf = new byte[16384];
                            int n;
                            int max = 3 * 1024 * 1024;
                            while ((n = in.read(buf)) > 0 && out.size() < max) {
                                out.write(buf, 0, n);
                            }
                            in.close();
                            c.disconnect();
                            result = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                            break;
                        }
                    } catch (Exception ignored) {
                        result = null;
                    }
                    if (result == null) {
                        js("window.onFetch('" + id + "',false,'')");
                    } else {
                        js("window.onFetch('" + id + "',true,'" + result + "')");
                    }
                }
            }, "m3u-fetch").start();
        }

        /** Lê wallpaper.jpg da pasta do app (se existir) e entrega como imagem reduzida. */
        @JavascriptInterface
        public void loadWallpaper() {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String data = "";
                    try {
                        File dir = getExternalFilesDir(null);
                        File f = dir == null ? null : new File(dir, "wallpaper.jpg");
                        if (f != null && f.exists()) {
                            BitmapFactory.Options o = new BitmapFactory.Options();
                            o.inJustDecodeBounds = true;
                            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                            int sample = 1;
                            while (o.outWidth / (sample * 2) >= 1920) {
                                sample *= 2;
                            }
                            o.inJustDecodeBounds = false;
                            o.inSampleSize = sample;
                            o.inPreferredConfig = Bitmap.Config.RGB_565;
                            Bitmap bmp = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                            if (bmp != null) {
                                ByteArrayOutputStream out = new ByteArrayOutputStream();
                                bmp.compress(Bitmap.CompressFormat.JPEG, 80, out);
                                bmp.recycle();
                                data = "data:image/jpeg;base64,"
                                        + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                            }
                        }
                    } catch (Exception ignored) {
                        data = "";
                    }
                    js("window.onWallpaper('" + data + "')");
                }
            }, "wallpaper").start();
        }
    }
}
