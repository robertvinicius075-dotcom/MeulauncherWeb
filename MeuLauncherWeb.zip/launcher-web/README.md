# Meu Launcher TV (versão HTML dentro de um app Android)

O seu `index.html` agora roda dentro de um app Android instalável (APK) que se registra como
tela inicial (`HOME`). A tela é HTML/CSS/JavaScript numa **WebView**; o Android só entrega à
página o que ela não consegue fazer sozinha.

> Estado: a interface foi testada num navegador com um Android simulado (foco pelas setas,
> abas, favoritos, lista M3U, player). O **APK ainda não foi compilado nem testado numa TV**.

## Como o HTML e o Android se integram

| Quem | O que faz |
| --- | --- |
| `assets/index.html` | Toda a tela: abas, favoritos, grade de apps, TV ao vivo, player, fundo, navegação por setas |
| `HomeActivity.java` | Abre a WebView, é o launcher (`HOME`), trata Home, Voltar e Menu do controle |
| Objeto `Android` (ponte) | `requestApps()`, `launch(pacote)`, `openSettings()`, `appInfo(pacote)`, `fetchText(id, url)`, `loadWallpaper()` |
| `window.onApps`, `onFetch`, `onWallpaper`, `handleBack`, `goHome`, `onMenu`, `stopPlayer` | O Android chama estas funções da página |
| `hls.min.js` | Biblioteca que toca canais `.m3u8`. É baixada na hora de compilar (veja abaixo) |

O que mudou em relação ao HTML original:
- **Apps de verdade:** a fileira "Seus aplicativos" lista o que está instalado na TV (inclusive o UNI TV).
  Antes eram ícones desenhados à mão.
- **Sem vídeo de fundo da internet** e sem imagens externas: pesava demais para uma TV de 1 GB.
  O fundo é uma cor (4 opções) ou a imagem `wallpaper.jpg`.
- **Sem o nome "Google TV".** Os cartões são os seus favoritos, não recomendações de filmes.
- **Setas do controle:** a página calcula sozinha para onde o foco vai (sem depender da WebView).
- **Segurança:** nomes de canais viram texto puro (antes eram inseridos como HTML, e uma lista
  maliciosa poderia controlar a ponte). A WebView não navega para fora da página local.
- **Listas M3U:** baixadas pelo Android (sem bloqueio de CORS) e guardadas na TV. Nenhuma lista
  vem incluída. Os dois canais de exemplo do seu arquivo continuam, mas podem estar fora do ar.
- **Pausa sozinho** ao abrir outro app, para o som não continuar tocando.

## Como usar

- Setas movem o foco. **OK** abre. **Segurar OK** num app: favoritar, mover para o início, informações.
- **Menu** (ou o botão Personalizar): escolher o fundo.
- **Voltar** sempre leva à aba Início; o launcher nunca fecha.
- No player: **Cima/Baixo** troca de canal, **OK** pausa, **Voltar** sai.
- Favoritos iniciais, se estiverem instalados: UNI TV, YouTube, Netflix, Globoplay, Prime Video, Disney+, Spotify.
- Fundo com imagem: copie `wallpaper.jpg` para `/sdcard/Android/data/com.meulauncher.tv/files/`
  (`adb push wallpaper.jpg /sdcard/Android/data/com.meulauncher.tv/files/wallpaper.jpg`).

## Como gerar o APK

**GitHub (sem Android Studio):** envie os arquivos para um repositório e rode
Actions → "Compilar APK" → Run workflow. O arquivo `.github/workflows/build-apk.yml` baixa o
`hls.min.js` do npm, compila e entrega `app-debug.apk` em Artifacts.

**Android Studio / Gradle:** antes de compilar, coloque o `hls.min.js` em
`app/src/main/assets/` (baixe o pacote `hls.js` versão 1.5.x do npm e use `dist/hls.min.js`).
Depois: Build → Build APK(s), ou `gradle assembleDebug` (JDK 17, Android SDK 34).
Sem esse arquivo o launcher funciona, mas canais `.m3u8` podem não tocar.

## Instalar e definir como tela inicial

```
adb connect IP-DA-TV:5555
adb install -r app-debug.apk
adb shell cmd package set-home-activity com.meulauncher.tv/.HomeActivity
```
Ou aperte Home na TV e escolha **Meu Launcher → Sempre**. Teste apertando Home dentro de outro app.
Para desfazer: `adb uninstall com.meulauncher.tv`.

## Limites que você precisa conhecer

- **A WebView da sua TV não tem como ser atualizada** (sem Play Store). O código foi escrito para
  navegadores bem antigos (Chrome 80+), mas se a tela abrir em branco ou quebrada, veja a versão em
  Configurações → Apps → Android System WebView. Se for muito velha, use a versão nativa em Java.
- **Memória:** a WebView usa mais RAM que um launcher nativo. Numa TV de 1 GB pode ficar lento,
  principalmente tocando vídeo.
- **Firmware:** algumas TVs recusam instalar um launcher ou ignoram o padrão escolhido.
- **Botões especiais do controle** (Netflix, YouTube, Entradas) continuam com o que o fabricante definiu.
- **Sem permissões especiais:** só internet (listas e canais) e a lista de apps com ícone de abrir.
- **Conteúdo:** use só listas e canais que você tem direito de assistir.
